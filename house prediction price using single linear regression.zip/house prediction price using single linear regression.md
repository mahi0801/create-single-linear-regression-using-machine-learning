```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
from sklearn import linear_model
```


```python
df=pd.read_excel(r"C:\Users\Administrator\Downloads\houjse prediction.xlsx")
print(df)
```

       area  price
    0  2000  50000
    1  3000  60000
    2  4000  70000
    3  6000  80000
    4  7000  90000
    


```python
%matplotlib inline
plt.scatter(df.area,df.price,color="green",marker="d")
plt.xlabel("area")
plt.ylabel("price")
```




    Text(0, 0.5, 'price')




    
![png](output_2_1.png)
    



```python
reg=linear_model.LinearRegression()
reg.fit(df[["area"]],df.price)
```




    LinearRegression()




```python
reg.predict(4000)
```


```python
#x

reg.coef_
```




    array([7.55813953])




```python
#formula
#y=m*x+c

```


```python
#y
reg.intercept_
```




    -200000.00000000006




```python
100*5000+-200000.00000000006
```




    299999.99999999994




```python
%matplotlib inline
plt.scatter(df.area,df.price,color="green",marker="d")
plt.xlabel("area")
plt.ylabel("price")
```




    Text(0, 0.5, 'price')




    
![png](output_9_1.png)
    



```python
%matplotlib inline
plt.scatter(df.area,df.price,color="green",marker="d")
plt.xlabel("area")
plt.ylabel("price")
plt.plot(df.area,reg.predict(df[["area"]]))
```




    [<matplotlib.lines.Line2D at 0x2489c576be0>]




    
![png](output_10_1.png)
    



```python

```
